package se.kth.iv1350.cashiersystem.integration;

import se.kth.iv1350.cashiersystem.dto.ItemDTO;
import se.kth.iv1350.cashiersystem.model.Discount;

public class DiscountDatabase {

	private Discount discount;

	public DiscountDatabase discountData(ItemDTO items, double totalCost, int customerID) {
		return null;
	}

}
