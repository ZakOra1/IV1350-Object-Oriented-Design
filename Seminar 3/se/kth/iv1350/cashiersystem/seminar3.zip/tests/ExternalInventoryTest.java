package se.kth.iv1350.cashiersystem.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.cashiersystem.dto.ItemDTO;
import se.kth.iv1350.cashiersystem.dto.SaleDTO;
import se.kth.iv1350.cashiersystem.integration.ExternalInventory;

import static org.junit.jupiter.api.Assertions.*;

class ExternalInventoryTest {
    private ExternalInventory inventory;

    @BeforeEach
    void setUp() {
        inventory = new ExternalInventory();
        inventory.addItemToInventory(new ItemDTO("abc123", "BigWheel Oatmeal", 29.90, 6, "Oatmeal description", 10));
        inventory.addItemToInventory(new ItemDTO("def456", "YouGoGo Blueberry", 14.90, 6, "Yoghurt description", 5));
    }

    @Test
    void testGetItemSuccess() {
        ItemDTO item = inventory.getItem("abc123", 1);
        assertNotNull(item, "Item should be found in inventory");
        assertEquals("abc123", item.getID(), "Item ID should match");
    }

    @Test
    void testGetItemInsufficientStock() {
        ItemDTO item = inventory.getItem("abc123", 20);
        assertNull(item, "Item should not be found due to insufficient stock");
    }

    @Test
    void testGetItemNotFound() {
        ItemDTO item = inventory.getItem("nonexistent", 1);
        assertNull(item, "Item should not be found in inventory");
    }
}