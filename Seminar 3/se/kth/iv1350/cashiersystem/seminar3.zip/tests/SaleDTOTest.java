package se.kth.iv1350.cashiersystem.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import se.kth.iv1350.cashiersystem.dto.ItemDTO;
import se.kth.iv1350.cashiersystem.dto.SaleDTO;

import static org.junit.jupiter.api.Assertions.*;

class SaleDTOTest {
    private SaleDTO sale;
    private ItemDTO item1;
    private ItemDTO item2;

    @BeforeEach
    void setUp() {
        sale = new SaleDTO();
        item1 = new ItemDTO("abc123", "BigWheel Oatmeal", 29.90, 6, "Oatmeal description", 10);
        item2 = new ItemDTO("def456", "YouGoGo Blueberry", 14.90, 6, "Yoghurt description", 5);
    }

    @Test
    void testAddItemToSale() {
        sale.addItemToSale(item1);
        assertEquals(1, sale.getItems().size(), "Item should be added to the sale");
        assertEquals(29.90, sale.getTotalPrice(), "Total price should be updated correctly");
    }

    @Test
    void testAddSameItemToSale() {
        sale.addItemToSale(item1);
        sale.addItemToSale(item1);
        assertEquals(1, sale.getItems().size(), "Same item should not be added twice");
        assertEquals(2, item1.getSaleQuantity(), "Sale quantity should be updated correctly");
        assertEquals(59.80, sale.getTotalPrice(), "Total price should reflect the quantity");
    }

    @Test
    void testGetTotalVAT() {
        sale.addItemToSale(item1);
        sale.addItemToSale(item2);
        double expectedVAT = item1.getVatAmount() + item2.getVatAmount();
        assertEquals(expectedVAT, sale.getVATAmount(), 0.01, "Total VAT should be calculated correctly");
    }

    @Test
    void testQuantityOfItemScanned() {
        sale.addItemToSale(item1);
        sale.addItemToSale(item1);
        int quantity = sale.quantityOfItemScanned(item1.getID());
        assertEquals(2, quantity, "Quantity of scanned item should be correct");
    }
}